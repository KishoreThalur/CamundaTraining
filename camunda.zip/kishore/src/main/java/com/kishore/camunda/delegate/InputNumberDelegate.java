package com.kishore.camunda.delegate;

import java.util.Scanner;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

@Service
public class InputNumberDelegate implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Enter Number a");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		System.out.println("Enter Number a");
		int b=sc.nextInt();
		execution.setVariable("n1", a);
		execution.setVariable("n2", b);
	}

}
