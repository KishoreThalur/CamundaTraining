package com.kishore.camunda.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kishore.camunda.service.AddService;

@RestController
@RequestMapping("/add")
public class AddController {
@Autowired
AddService addService;

	@GetMapping
	public String addService(){
		addService.add();
		return "Process Instantiated";
	}
	
}
