package com.kishore.camunda.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

//import jdk.internal.org.jline.utils.Log;
//import lombok.extern.slf4j.Slf4j;

@Service
//@Slf4j
public class AddNumbersDelegate implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
//		log.info("AddNumberDelegate Called");	
		int a=(int)execution.getVariable("n1");
		int b=(int)execution.getVariable("n2");
		int sum=a+b;
		execution.setVariable("sum", sum);
	}

}
