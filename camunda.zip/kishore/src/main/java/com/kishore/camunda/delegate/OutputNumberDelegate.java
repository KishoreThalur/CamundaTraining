package com.kishore.camunda.delegate;

import java.util.Scanner;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Service;

@Service
public class OutputNumberDelegate implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		int sum=(int)execution.getVariable("sum");
		System.out.println("Sum is : "+sum);
		
	}

}
