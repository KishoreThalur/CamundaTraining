package com.kishore.camunda.service;

import org.camunda.bpm.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AddService {

	@Autowired
	RuntimeService runTimeService;
	
	public void add(){
		runTimeService.startProcessInstanceByKey("add_process");
	}
	
}
